* WoWMaevahEmpire - World of Warcraft phpBB theme created by Moonclaw/M�evah (http://www.wowcr.net/) - Code modifications
* -------------------------------------------------------------------------------------------------------------------
*

These files keep traces of every modification made from phpBB subSilver2 template to WoWMaevahEmpire.

They are mainly a reminder for the author of the theme to know what to do when a file is changed in the original subSilver template, you should not have much to do with them (except if you want to and you know what you're doing ;-).

(To keep the names more simple, "subSilver2" is considered as "WoWMaevahEmpire 3.0.00". And the phpBB version on which the modification is based is indicated in the end of the file name.)

(Pay attention the lines numbers are only there for approximative informative purpose and may change from one phpBB version to another, or when installing mods and/or editing the code.)

Unlike phpBB2 (hm, I'm not even sure), the user groups colors in phpBB3 are defined in the administration panel and do not depend from the template.

This template is test with Firefox 2 and Internet Explorer 7.